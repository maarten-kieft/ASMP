==============
Version 4.5.11
==============

Version 4.5.11 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.5.11

Bugs Fixed
----------

* The ``runmodwsgi`` option when using Django application integration would
  fail on older Django versions up to Django 1.7.
